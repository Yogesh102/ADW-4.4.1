# ADW Microsoft Office 365 Extension 

Provides additional features for Office 365 integration with Alfresco Content Application and Digital Workspace.

## Enabling the plugin

In the `apps/content-ee/src/app.config.json`, update the `plugins` section:

```json
{
  "plugins": {
    "microsoftOnline": true
  }
}
```
