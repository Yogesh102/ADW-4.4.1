# ADW Governance Extension

Provides Governance features to the Alfresco Content Application and Digital Workspace.

## Enabling the plugin

In the `apps/content-ee/src/app.config.json`, update the `plugins` section:

```json
{
  "plugins": {
    "contentService": true
  }
}
```
