/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProcessInstance } from '@alfresco/adf-process-services';
import { loadSelectedProcess } from '../../../store/actions/process-details-ext.actions';
import { Store } from '@ngrx/store';
import { takeUntil } from 'rxjs/operators';
import { getSelectedProcess } from '../../../process-services-ext.selector';
import { Subject } from 'rxjs';
import { ProcessDetailsExtActions } from '../../../process-details-ext-actions-types';

@Component({
    selector: 'aps-process-details-page-ext',
    templateUrl: './process-details-page-ext.component.html',
    styleUrls: ['./process-details-page-ext.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class ProcessDetailsPageExtComponent implements OnInit, OnDestroy {
    processInstanceDetails: ProcessInstance = {};
    showMetadata = false;

    private onDestroy$ = new Subject<void>();

    constructor(private route: ActivatedRoute, private store: Store) {}

    ngOnInit(): void {
        this.route.params.subscribe((params) => {
            this.loadProcessDetails(params['processId']);
        });

        this.store
            .select(getSelectedProcess)
            .pipe(takeUntil(this.onDestroy$))
            .subscribe((processInstanceDetails) => {
                this.processInstanceDetails = processInstanceDetails;
            });
    }

    private loadProcessDetails(processInstanceId: string) {
        this.store.dispatch(
            loadSelectedProcess({
                processInstanceId,
            })
        );
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
        this.onDestroy$.complete();
        this.store.dispatch(ProcessDetailsExtActions.resetSelectedProcess());
    }
}
