/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProcessModule } from '@alfresco/adf-process-services';
import { TranslateModule } from '@ngx-translate/core';
import { EffectsModule } from '@ngrx/effects';

import { ExtensionService } from '@alfresco/adf-extensions';
import { PageLayoutModule, SharedToolbarModule } from '@alfresco/aca-shared';

import { ProcessListExtComponent } from './components/process-list-ext.component';
import { ProcessListExtEffect } from './effects/process-list-ext.effect';

import { CoreModule } from '@alfresco/adf-core';
import { MatListModule } from '@angular/material/list';
import { MatRippleModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
    imports: [
        CommonModule,
        MatListModule,
        MatRippleModule,
        MatIconModule,
        TranslateModule,
        CoreModule,
        PageLayoutModule,
        ProcessModule,
        EffectsModule.forFeature([ProcessListExtEffect]),
        SharedToolbarModule
    ],
    declarations: [ProcessListExtComponent],
})
export class ProcessListModule {
    constructor(extensions: ExtensionService) {
        extensions.setComponents({
            'process-services-plugin.components.process-list-ext': ProcessListExtComponent,
        });
    }
}
